<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Utility;

use Dbm\Core\Paths;

final class PagesFixedRoutesUtility
{
    /**
     * @return array<array{
     *    page_key: string,
     *    language: string,
     *    slug: string,
     *    route: string
     * }>
     */
    public static function routes(): array
    {
        $pathCache = Paths::joinPaths(
            Paths::basePath(),
            'storage',
            'cache',
            'cmslite',
            'index.php'
        );

        if (!file_exists($pathCache)) {
            return [];
        }

        $index = include $pathCache;

        $routes = [];

        foreach ($index as $path => $page) {

            $parent = $page['parent'] ?? null;

            if (!preg_match('#^[a-z]{2}$#', (string) $parent)) {
                continue;
            }

            [$language, $slug] = explode('/', $path, 2);

            $routes[] = [
                'page_key' => $page['page_key'] ?? $slug,
                'language' => strtoupper($page['language'] ?? $language),
                'slug' => $page['slug'] ?? $slug,
                'route' => 'cmslite_show',
            ];
        }

        usort(
            $routes,
            static fn(array $a, array $b): int
                => strcmp($a['page_key'], $b['page_key'])
        );

        return $routes;
    }
}
