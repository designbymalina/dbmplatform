<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Utility;

use Dbm\Localization\LanguageHelper;

final class CmsLiteLanguageUrlResolver
{
    public static function resolve(string $pageKey, string $toLanguage): string
    {
        $routes = PagesFixedRoutesUtility::routes();
        // @INFO Docelowo użyj UrlGenerator.
        $baseUrl = rtrim(parse_url(getenv('APP_URL'), PHP_URL_PATH) ?: '', '/');

        foreach ($routes as $route) {
            if ($route['page_key'] !== $pageKey || strtoupper($route['language']) !== strtoupper($toLanguage)) {
                continue;
            }

            return strtoupper($toLanguage) === LanguageHelper::getDefaultLanguage()
                ? $baseUrl . '/' . $route['slug']
                : $baseUrl . '/' . strtolower($toLanguage) . '/' . $route['slug'];
        }

        return '/';
    }
}
