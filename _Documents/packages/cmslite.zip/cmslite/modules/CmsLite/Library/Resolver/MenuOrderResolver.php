<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Resolver;

use Mod\CmsLite\Library\CmsIndexBuilder;

final class MenuOrderResolver
{
    public function __construct(
        private readonly CmsIndexBuilder $indexBuilder
    ) {}

    public function resolve(string $menu, ?string $lang = null): int
    {
        $pages = $this->indexBuilder->load();

        $max = 0;

        foreach ($pages as $page) {
            if (($page['menu'] ?? null) !== $menu) {
                continue;
            }

            $pagePath = $page['path'];

            // --- filtr języka
            if ($lang !== null) {
                if (!str_starts_with($pagePath, $lang . '/')) {
                    continue;
                }
            } else {
                if (str_contains($pagePath, '/')) {
                    continue;
                }
            }

            $order = $page['menu_order'] ?? null;

            // ignoruj null i 0
            if ($order === null || $order <= 0) {
                continue;
            }

            if ($order > $max) {
                $max = $order;
            }
        }

        return $max > 0 ? $max + 1 : 1;
    }
}
