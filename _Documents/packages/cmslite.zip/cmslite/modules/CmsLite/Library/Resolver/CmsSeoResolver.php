<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Resolver;

use Dbm\Localization\CurrentLanguage;
use Dbm\Localization\LanguageHelper;
use Dbm\Routing\Contracts\UrlGeneratorInterface;
use Mod\CmsLite\Library\StaticCmsReader;

final class CmsSeoResolver
{
    public function __construct(
        private readonly StaticCmsReader $reader,
        private readonly UrlGeneratorInterface $urlGenerator,
        private readonly CurrentLanguage $currentLanguage,
    ) {}

    public function resolveCanonical(string $pageKey): ?string
    {
        $language = $this->currentLanguage->get()
            ?? LanguageHelper::getDefaultLanguage();

        foreach ($this->reader->getAllPages() as $page) {
            if ($page['page_key'] !== $pageKey) {
                continue;
            }

            if ($page['language'] !== $language) {
                continue;
            }

            return $this->absolutePublicPath($page['path']);
        }

        return null;
    }

    public function resolveHomepageCanonical(): string
    {
        $language = strtoupper(
            $this->currentLanguage->get()
            ?? LanguageHelper::getDefaultLanguage()
        );

        if ($language === LanguageHelper::getDefaultLanguage()) {
            return $this->urlGenerator->absolutePath('/');
        }

        return $this->urlGenerator->absolutePath(
            strtolower($language) . '/'
        );
    }

    /**
     * @return array<array{lang:string,url:string}>
     */
    public function resolveHreflang(string $pageKey): array
    {
        $links = [];
        $defaultUrl = null;
        $defaultLanguage = strtolower(LanguageHelper::getDefaultLanguage());

        foreach ($this->reader->getAllPages() as $page) {
            if ($page['page_key'] !== $pageKey) {
                continue;
            }

            $url = $this->absolutePublicPath($page['path']);

            $language = strtolower((string) $page['language']);

            $links[] = [
                'lang' => $language,
                'url' => $url,
            ];

            if ($language === $defaultLanguage) {
                $defaultUrl = $url;
            }
        }

        $this->addDefaultLink($links, $defaultUrl);

        $this->sortLinks($links);

        return $links;
    }

    /**
     * Linki hreflang dla strony głównej.
     *
     * @return array<array{lang:string,url:string}>
     */
    public function resolveHomepage(): array
    {
        $defaultLanguage = strtolower(LanguageHelper::getDefaultLanguage());

        $links = [];

        foreach (LanguageHelper::getAvailableLanguages() as $language) {
            $lang = strtolower($language);

            $links[] = [
                'lang' => $lang,
                'url' => $lang === $defaultLanguage
                    ? $this->urlGenerator->absolutePath('/')
                    : $this->urlGenerator->absolutePath($lang . '/'),
            ];
        }

        $this->addDefaultLink(
            $links,
            $this->urlGenerator->absolutePath('/')
        );

        $this->sortLinks($links);

        return $links;
    }

    // ===== Private methods =====

    /**
     * @INFO: Domyślny język nie ma prefiksu.
     */
    private function buildPublicPath(string $path): string
    {
        $path = ltrim($path, '/');

        $prefix = strtolower(LanguageHelper::getDefaultLanguage()) . '/';

        if (str_starts_with($path, $prefix)) {
            return substr($path, strlen($prefix));
        }

        return $path;
    }

    private function absolutePublicPath(string $path): string
    {
        return $this->urlGenerator->absolutePath(
            $this->buildPublicPath($path)
        );
    }

    /**
     * @param array<array{lang:string,url:string}> $links
     */
    private function addDefaultLink(array &$links, ?string $defaultUrl): void
    {
        if ($defaultUrl === null) {
            return;
        }

        $links[] = [
            'lang' => 'x-default',
            'url' => $defaultUrl,
        ];
    }

    /**
     * @param array<array{lang:string,url:string}> $links
     */
    private function sortLinks(array &$links): void
    {
        usort(
            $links,
            static fn(array $a, array $b): int
                => strcmp($a['lang'], $b['lang'])
        );
    }
}
