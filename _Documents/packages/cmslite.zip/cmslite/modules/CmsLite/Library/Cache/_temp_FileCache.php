<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 *
 * @INFO Klasa może być przydatna przy: API responses, external requests,
 * dynamiczne dane (np. query builder), TTL (czas życia cache).
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Cache;

use Dbm\Core\Paths;
use Dbm\Infrastructure\Filesystem\Filesystem;

final class _temp_FileCache // implements CacheInterface
{
    public function __construct(
        private Filesystem $fs,
        private ?string $cacheDir = null
    ) {
        $this->cacheDir ??= Paths::joinPaths(Paths::varPath(), 'cache', 'cmslite');

        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0o775, true);
        }
    }

    public function get(string $key): ?string
    {
        $file = $this->getFilePath($key);

        $data = $this->fs->readFile($file);

        if ($data === null) {
            return null;
        }

        $decoded = json_decode($data, true);

        if (!$decoded || ($decoded['expires'] ?? 0) < time()) {
            $this->fs->deleteFile($file);
            return null;
        }

        return $decoded['value'] ?? null;
    }

    public function set(string $key, string $value, int $ttl): void
    {
        $file = $this->getFilePath($key);

        $data = json_encode([
            'expires' => time() + $ttl,
            'value' => $value,
        ]);

        $this->fs->saveFile($file, $data);
    }

    public function clear(): void
    {
        foreach (glob($this->cacheDir . '/*.cache') as $file) {
            $this->fs->deleteFile($file);
        }
    }

    public function delete(string $key): void
    {
        $file = $this->getFilePath($key);

        if ($this->fs->isFile($file)) {
            $this->fs->deleteFile($file);
        }
    }

    public function getCacheKey(string $path): string
    {
        return 'cms_page_' . md5($path);
    }

    private function getFilePath(string $key): string
    {
        return rtrim($this->cacheDir, '/') . '/' . md5($key) . '.cache';
    }
}
