<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Parser;

use Mod\CmsLite\Library\Content\ContentProcessor;
use Mod\CmsLite\Library\Dto\CmsPageDto;

final class FrontmatterParser
{
    private const FILE_ITEM_PARSER = '/^---\R(.*?)\R---\R(.*)$/s';

    public function __construct(
        private readonly SimpleYamlParser $yaml,
        private readonly ContentProcessor $processor
    ) {}

    public function parse(string $raw): CmsPageDto
    {
        if (!preg_match(self::FILE_ITEM_PARSER, $raw, $matches)) {
            throw new \RuntimeException('Invalid CMS frontmatter format. Expected: --- YAML --- content');
        }

        $meta = $this->yaml->parse(trim($matches[1]));
        $content = $this->processor->process(trim($matches[2]));

        $data = new CmsPageDto(
            slug: $meta['slug'] ?? '',
            title: $meta['title'] ?? '',
            description: $meta['description'] ?? '',
            keywords: $meta['keywords'] ?? '',
            content: $content,
            menu: $meta['menu'] ?? null,
            menu_order: is_numeric($meta['menu_order'] ?? null) ? (int) $meta['menu_order'] : null,
        );

        return $data;
    }
}
