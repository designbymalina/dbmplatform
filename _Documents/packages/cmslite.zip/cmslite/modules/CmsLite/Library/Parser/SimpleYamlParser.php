<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Parser;

final class SimpleYamlParser
{
    /**
     * @return array<string, string>
     */
    public function parse(string $yaml): array
    {
        $result = [];

        $lines = preg_split('/\r\n|\r|\n/', $yaml);

        foreach ($lines as $line) {
            $line = trim($line);

            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            if (!str_contains($line, ':')) {
                continue;
            }

            [$key, $value] = explode(':', $line, 2);

            $result[trim($key)] = trim(trim($value), '"\'');
        }

        return $result;
    }
}
