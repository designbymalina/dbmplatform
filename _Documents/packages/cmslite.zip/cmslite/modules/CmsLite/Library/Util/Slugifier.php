<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 *
 * @INFO Używane w module (controllers, services).
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Util;

final class Slugifier
{
    public static function slugify(string $text): string
    {
        $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
        $text = strtolower($text);
        $text = preg_replace('~[^a-z0-9]+~', '-', $text);

        return trim($text, '-');
    }
}
