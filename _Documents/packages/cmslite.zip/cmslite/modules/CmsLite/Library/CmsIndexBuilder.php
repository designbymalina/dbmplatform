<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Core\Paths;
use Mod\CmsLite\Library\Loader\FileLoader;

final class CmsIndexBuilder
{
    public const CACHE_FILE_PATH = 'storage/cache/cmslite/index.php';
    public const CONTENT_DIR = 'data/content';

    /**
     * @return array<string, mixed>
     */
    public function load(bool &$rebuilt = false): array
    {
        $file = Paths::joinPaths(Paths::basePath(), self::CACHE_FILE_PATH);
        $contentDir = Paths::joinPaths(Paths::basePath(), self::CONTENT_DIR);

        if ($this->isCacheStale($file, $contentDir)) {
            $this->rebuild();
            $rebuilt = true;
        }

        return is_file($file) ? require $file : [];
    }

    public function rebuild(): void
    {
        $base = Paths::joinPaths(Paths::basePath(), self::CONTENT_DIR);

        if (!is_dir($base)) {
            return;
        }

        $pages = [];

        $addPage = function (string $path, \SplFileInfo $file) use (&$pages) {
            $meta = $this->readFrontmatter($file);

            $pages[$path] = [
                'page_key' => $meta['page_key'] ?? '',
                'language' => $meta['language'] ?? '',
                'slug' => $meta['slug'] ?? '',
                'title' => $meta['title'] ?? '',
                'description' => $meta['description'] ?? '',
                'keywords' => $meta['keywords'] ?? '',
                'menu' => $meta['menu'] ?? null,
                'menu_order' => is_numeric($meta['menu_order'] ?? null) ? (int) $meta['menu_order'] : null,
                'parent' => $this->parent($path), // używamy path (nie relative)
                'path' => $path,
            ];
        };

        // --- ROOT (single lang)
        foreach (glob($base . '/*.' . FileLoader::DEFAULT_EXTENSION) as $filePath) {
            $file = new \SplFileInfo($filePath);

            $relative = $this->normalizeCmsPath($filePath);
            $relative = preg_replace(FileLoader::EXT_PATTERN, '', $relative);

            $addPage($relative, $file);
        }

        // --- MULTI LANG
        foreach (scandir($base) as $lang) {
            if ($lang === '.' || $lang === '..') {
                continue;
            }

            $langDir = Paths::joinPaths($base, $lang);

            if (!is_dir($langDir)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($langDir, \FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $file) {
                if (!$file->isFile() || $file->getExtension() !== FileLoader::DEFAULT_EXTENSION) {
                    continue;
                }

                $relative = $this->normalizeCmsPath($file->getPathname());
                $relative = preg_replace(FileLoader::EXT_PATTERN, '', $relative);

                // zabezpieczenie przed en/en
                if (str_starts_with($relative, $lang . '/')) {
                    $path = $relative;
                } else {
                    $path = $lang . '/' . $relative;
                }

                $addPage($path, $file);
            }
        }

        uasort($pages, fn($a, $b) => $a['menu_order'] <=> $b['menu_order']);

        $cacheFile = Paths::joinPaths(Paths::basePath(), self::CACHE_FILE_PATH);
        $dir = dirname($cacheFile);

        if (!is_dir($dir) && !mkdir($dir, 0o775, true) && !is_dir($dir)) {
            throw new \RuntimeException("Cannot create dir: " . $dir);
        }

        file_put_contents(
            $cacheFile,
            "<?php\n\n// This file is auto-generated for the CmsLite cache index."
            . "\n\nreturn " . $this->exportArray($pages) . ";\n"
        );
    }

    /**
     * @return array{
     *   page_key?: string,
     *   language?: string,
     *   slug?: string,
     *   title?: string,
     *   description?: string,
     *   keywords?: string,
     *   menu?: string|null,
     *   menu_order?: int
     * }
     */
    private function readFrontmatter(\SplFileInfo $file): array
    {
        $meta = [];
        $handle = fopen($file->getPathname(), 'r');

        if ($handle === false) {
            return $meta;
        }

        $inFrontmatter = false;

        while (($line = fgets($handle)) !== false) {
            $line = trim($line);

            if ($line === '---') {
                if (!$inFrontmatter) {
                    $inFrontmatter = true;
                    continue;
                }

                break;
            }

            if (!$inFrontmatter || $line === '') {
                continue;
            }

            if (str_starts_with($line, 'page_key:')) {
                $meta['page_key'] = trim(substr($line, 9));
                continue;
            }

            if (str_starts_with($line, 'language:')) {
                $meta['language'] = trim(substr($line, 9));
                continue;
            }

            if (str_starts_with($line, 'slug:')) {
                $meta['slug'] = trim(substr($line, 6));
                continue;
            }

            if (str_starts_with($line, 'title:')) {
                $meta['title'] = trim(substr($line, 6));
                continue;
            }

            if (str_starts_with($line, 'description:')) {
                $meta['description'] = trim(substr($line, 12));
                continue;
            }

            if (str_starts_with($line, 'keywords:')) {
                $meta['keywords'] = trim(substr($line, 9));
                continue;
            }

            if (str_starts_with($line, 'menu:')) {
                $val = trim(substr($line, 5));
                $meta['menu'] = $val !== '' ? $val : null;
                continue;
            }

            if (str_starts_with($line, 'menu_order:')) {
                $value = trim(substr($line, 11));

                if ($value === '') {
                    $meta['menu_order'] = null;
                } else {
                    $meta['menu_order'] = (int) $value;
                }

                continue;
            }
        }

        fclose($handle);

        return $meta;
    }

    private function parent(string $path): ?string
    {
        $path = trim($path, '/');

        if (!str_contains($path, '/')) {
            return null;
        }

        $parts = explode('/', $path);
        array_pop($parts);

        return implode('/', $parts);
    }

    private function normalizeCmsPath(string $fullPath): string
    {
        $fullPath = str_replace('\\', '/', $fullPath);

        $base = str_replace('\\', '/', Paths::joinPaths(
            Paths::basePath(),
            self::CONTENT_DIR
        ));

        if (!str_starts_with($fullPath, $base)) {
            return $fullPath;
        }

        return ltrim(substr($fullPath, strlen($base)), '/');
    }

    private function isCacheStale(string $cacheFile, string $contentDir): bool
    {
        if (!is_file($cacheFile)) {
            return true;
        }

        $cacheTime = filemtime($cacheFile);

        // TTL (np. 1h)
        $ttl = getenv('CMS_INDEX_TTL');
        $ttl = is_numeric($ttl) ? (int) $ttl : 3600;

        if ((time() - $cacheTime) > $ttl) {
            return true;
        }

        // sprawdzenie zmian plików
        foreach (new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($contentDir, \FilesystemIterator::SKIP_DOTS)
        ) as $file) {
            if ($file->isFile() && $file->getMTime() > $cacheTime) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string,mixed> $data
     */
    private function exportArray(array $data): string
    {
        $export = var_export($data, true);

        $export = str_replace(
            ["array (", ")"],
            ["[", "]"],
            $export
        );

        $export = preg_replace('/=>\s+\[/', '=> [', $export);
        $export = preg_replace('/\[\s*\]/', '[]', $export);

        return $export;
    }
}
