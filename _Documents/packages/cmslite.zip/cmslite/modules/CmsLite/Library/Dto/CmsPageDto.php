<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Dto;

final class CmsPageDto
{
    public function __construct(
        public readonly string $slug,
        public readonly string $title,
        public readonly string $description,
        public readonly string $keywords,
        public readonly string $content,
        public ?string $menu = null,
        public ?int $menu_order = null,
        public ?string $path = null
    ) {}

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'slug' => $this->slug,
            'title' => $this->title,
            'description' => $this->description,
            'keywords' => $this->keywords,
            'content' => $this->content,
            'menu' => $this->menu,
            'menu_order' => $this->menu_order,
            'path' => $this->path,
        ];
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function fromArray(array $data): self
    {
        return new self(
            slug: $data['slug'] ?? '',
            title: $data['title'] ?? '',
            description: $data['description'] ?? '',
            keywords: $data['keywords'] ?? '',
            content: $data['content'] ?? '',
            menu: $data['menu'] ?? null,
            menu_order: $data['menu_order'] ?? null,
            path: $data['path'] ?? null
        );
    }
}
