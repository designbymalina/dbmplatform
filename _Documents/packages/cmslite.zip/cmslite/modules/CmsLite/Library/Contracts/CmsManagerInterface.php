<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Contracts;

use Mod\CmsLite\Library\Dto\CmsPageDto;

interface CmsManagerInterface
{
    public function get(string $path): CmsPageDto;

    public function create(string $path, CmsPageDto $dto): void;

    public function update(string $path, CmsPageDto $dto): void;

    public function delete(string $path): void;

    public function exists(string $path): bool;
}
