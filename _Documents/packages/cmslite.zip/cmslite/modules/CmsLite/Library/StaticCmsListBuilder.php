<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Core\Paths;
use Dbm\Localization\LanguageHelper;
use Mod\CmsLite\Library\Loader\FileLoader;

final class StaticCmsListBuilder
{
    /**
     * @param array<string, array{
     *   page_key: string,
     *   language: string,
     *   slug: string,
     *   title: string,
     *   description: string,
     *   keywords: string,
     *   menu: ?string,
     *   menu_order: int,
     *   parent: ?string,
     *   path: string
     * }> $pages
     *
     * @return array<int, array{
     *   full_path: string,
     *   path: string,
     *   key: string,
     *   file: string,
     *   url: string,
     *   lang: string,
     *   menu: ?string,
     * }>
     */
    public function buildList(array $pages): array
    {
        $dirContent = Paths::joinPaths(Paths::basePath(), 'data', 'content');
        $ext = '.' . FileLoader::DEFAULT_EXTENSION;

        $cmsTree = [];

        foreach ($pages as $page) {
            $key = $page['page_key'];
            $path = $page['path'];

            $url = '/' . $this->buildPublicPath($path);

            $hasLang = preg_match('#^[a-z]{2}/#', $path);

            if ($hasLang) {
                [$lang, $slug] = explode('/', $path, 2);

                $fullPath = Paths::joinPaths($dirContent, $lang, $slug . $ext);
                $file = $lang . '/' . $slug . $ext;
            } else {
                $lang = 'default';
                $slug = $path;

                $fullPath = Paths::joinPaths($dirContent, $slug . $ext);
                $file = $slug . $ext;
            }

            $cmsTree[] = [
                'full_path' => $fullPath,
                'path' => $path,
                'key' => $key,
                'file' => $file,
                'url' => $url,
                'lang' => $lang,
                'menu' => $page['menu'] ?? null,
            ];
        }

        usort(
            $cmsTree,
            fn($a, $b) => strcmp($a['path'], $b['path'])
        );

        return $cmsTree;
    }

    /**
     * @INFO Default language URLs do not contain the language prefix.
     *
     * Identycznej logiki potrzebują już trzy klasy:
     * CmsIndexBuilder, CmsSeoResolver, StaticCmsListBuilder
     * dlatego można wydzielić metodę do osobnej klasy np. CmsPathResolver.
     */
    private function buildPublicPath(string $path): string
    {
        $path = ltrim($path, '/');

        $prefix = strtolower(LanguageHelper::getDefaultLanguage()) . '/';

        if (str_starts_with($path, $prefix)) {
            return substr($path, strlen($prefix));
        }

        return $path;
    }
}
