<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Core\Paths;
use Mod\CmsLite\Library\Loader\FileLoader;

final class StaticCmsListBuilder
{
    /**
     * @param array<string, array{
     *   title: string,
     *   description: string,
     *   keywords: string,
     *   menu: ?string,
     *   menu_order: int,
     *   parent: ?string,
     *   path: string
     * }> $pages
     *
     * @return array<int, array{
     *   url: string,
     *   file: string,
     *   path: string,
     *   lang: string,
     *   full_path: string
     * }>
     */
    public function buildList(array $pages): array
    {
        $dirContent = Paths::joinPaths(Paths::basePath(), 'data', 'content');
        $ext = '.' . FileLoader::DEFAULT_EXTENSION;

        $cmsTree = [];

        foreach ($pages as $page) {
            $path = $page['path'];

            $hasLang = preg_match('#^[a-z]{2}/#', $path);

            if ($hasLang) {
                [$lang, $slug] = explode('/', $path, 2);

                $fullPath = Paths::joinPaths($dirContent, $lang, $slug . $ext);

                $file = $lang . '/' . $slug . $ext;
                $url = '/' . $slug;
            } else {
                $lang = 'default';
                $slug = $path;

                $fullPath = Paths::joinPaths($dirContent, $slug . $ext);

                $file = $slug . $ext;
                $url = '/' . $slug;
            }

            $cmsTree[] = [
                'full_path' => $fullPath,
                'path' => $path,
                'file' => $file,
                'url' => $url,
                'lang' => $lang,
                'menu' => $page['menu'] ?? null,
            ];
        }

        usort(
            $cmsTree,
            fn($a, $b) => strcmp($a['path'], $b['path'])
        );

        return $cmsTree;
    }
}
