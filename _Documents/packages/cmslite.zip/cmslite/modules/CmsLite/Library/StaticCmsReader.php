<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Localization\CurrentLanguage;
use Dbm\Localization\LanguageHelper;
use Mod\CmsLite\Library\Dto\CmsPageDto;
use Mod\CmsLite\Library\Loader\FileLoader;
use Mod\CmsLite\Library\Parser\FrontmatterParser;

final class StaticCmsReader
{
    public function __construct(
        private readonly CmsIndexBuilder $indexBuilder,
        private readonly FileLoader $loader,
        private readonly FrontmatterParser $parser,
        private readonly CurrentLanguage $currentLanguage
    ) {}

    /**
     * @return array<string, array{
     *     page_key: string,
     *     language: string,
     *     slug: string,
     *     title: string,
     *     description: string,
     *     keywords: string,
     *     menu: ?string,
     *     menu_order: int,
     *     parent: ?string,
     *     path: string
     * }>
     */
    public function getAllPages(bool &$rebuilt = false): array
    {
        return $this->indexBuilder->load($rebuilt);
    }

    public function get(string $path): CmsPageDto
    {
        $path = $this->normalizePath($path);

        $raw = $this->loader->load($path);

        return $this->parser->parse($raw);
    }

    // ===== Publiczny helper dla frontu, używany w kontrolerach =====

    public function buildCmsPath(string $slug, ?string $prefix = null): string
    {
        $slug = trim($slug, '/');

        if ($slug === '') {
            throw new \InvalidArgumentException('Slug is required');
        }

        $langs = LanguageHelper::getAvailableLanguages();
        $isMultilang = count($langs) > 1;
        $lang = $isMultilang ? $this->currentLanguage->get() : null;

        $prefix = $prefix ? trim($prefix, '/') : null;

        $path = $prefix ? "{$prefix}/{$slug}" : $slug;

        if ($isMultilang && $lang) {
            $path = "{$lang}/{$path}";
        }

        if (str_contains($path, '..')) {
            throw new \RuntimeException('Invalid path');
        }

        return $path;
    }

    public function rebuildCms(): void
    {
        $this->indexBuilder->rebuild();
    }

    // ===== Private =====

    private function normalizePath(string $path): string
    {
        $path = trim($path);
        $path = strtolower($path);
        $path = preg_replace(FileLoader::EXT_PATTERN, '', $path);

        if (!$this->hasLanguagePrefix($path)) {
            $path = strtolower(
                LanguageHelper::getDefaultLanguage()
            ) . '/' . ltrim($path, '/');
        }

        return $path;
    }

    private function hasLanguagePrefix(string $path): bool
    {
        return (bool) preg_match(
            '#^[a-z]{2}/#',
            $path
        );
    }
}
