<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Localization\LanguageHelper;

final class StaticCmsTreeBuilder
{
    /**
     * @return array<string, list<array{
     *  path: string,
     *  relative: string,
     *  name: string,
     *  ext: string|null,
     *  isFile: bool,
     *  level: int
     * }>>
     */
    public function build(string $baseDir): array
    {
        if (!is_dir($baseDir)) {
            return [];
        }

        $result = [];

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($baseDir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $base = rtrim(str_replace('\\', '/', $baseDir), '/');

        foreach ($iterator as $file) {
            $fullPath = str_replace('\\', '/', $file->getPathname());
            $relative = ltrim(substr($fullPath, strlen($base)), '/');
            $relative = preg_replace('/\.[^.]+$/', '', $relative);
            $name = preg_replace('/\.[^.]+$/', '', $file->getFilename());
            $isFile = $file->isFile();

            $result[] = [
                'path' => $fullPath,
                'relative' => $relative,
                'name' => $name,
                'ext' => $isFile ? $file->getExtension() : null,
                'isFile' => $isFile,
                'level' => substr_count($relative, '/'),
            ];
        }

        return $this->groupAndSort($result);
    }

    /**
     * Grupuje (root + języki) i sortuje elementy.
     *
     * @param array<int, array{
     *  path: string,
     *  relative: string,
     *  name: string,
     *  ext: string|null,
     *  isFile: bool,
     *  level: int
     * }> $items
     *
     * @return array<string, list<array{
     *  path: string,
     *  relative: string,
     *  name: string,
     *  ext: string|null,
     *  isFile: bool,
     *  level: int
     * }>>
     */
    private function groupAndSort(array $items): array
    {
        $languages = array_map('strtolower', LanguageHelper::getAvailableLanguages());

        $groups = ['root' => []];

        foreach ($languages as $lang) {
            $groups[$lang] = [];
        }

        // --- GROUPING
        foreach ($items as $item) {
            $rel = $item['relative'];

            $matched = false;

            foreach ($languages as $lang) {
                if (str_starts_with($rel, $lang . '/')) {
                    $groups[$lang][] = $item;
                    $matched = true;
                    break;
                }
            }

            if (!$matched) {
                if (!$item['isFile'] && in_array($item['name'], $languages, true)) {
                    continue;
                }

                $groups['root'][] = $item;
            }
        }

        // --- SORT
        $sortFn = function ($a, $b) {
            if ($a['level'] !== $b['level']) {
                return $a['level'] <=> $b['level'];
            }

            if ($a['isFile'] !== $b['isFile']) {
                return $a['isFile'] ? -1 : 1;
            }

            return strcmp($a['name'], $b['name']);
        };

        foreach ($groups as &$group) {
            usort($group, $sortFn);
        }

        unset($group);

        return $groups;
    }
}
