<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Core\Paths;
use Dbm\Infrastructure\Filesystem\Filesystem;
use Mod\CmsLite\Library\Contracts\CmsManagerInterface;
use Mod\CmsLite\Library\Dto\CmsPageDto;
use Mod\CmsLite\Library\Loader\FileLoader;
use Mod\CmsLite\Library\Parser\FrontmatterParser;
use Mod\CmsLite\Library\Resolver\MenuOrderResolver;
use RuntimeException;

final class StaticCmsManager implements CmsManagerInterface
{
    public function __construct(
        private readonly FileLoader $loader,
        private readonly FrontmatterParser $parser,
        private readonly Filesystem $fs,
        private readonly MenuOrderResolver $orderMenu
    ) {}

    public function get(string $path): CmsPageDto
    {
        $path = $this->normalizePath($path);

        $raw = $this->loader->load($path);

        return $this->parser->parse($raw);
    }

    public function create(string $path, CmsPageDto $dto): void
    {
        $path = $this->normalizePath($path);

        if ($this->exists($path)) {
            throw new RuntimeException("File exists: {$path}");
        }

        if ($dto->menu !== null && $dto->menu_order === null) {
            $lang = $this->extractLang($path);

            $dto->menu_order = $this->orderMenu->resolve(
                $dto->menu,
                $lang
            );
        }

        $this->write($path, $dto);
        $this->invalidateIndex();

        $fullPath = $this->loader->getFullPath($path);
        $this->fileBackup($fullPath, false);
    }

    public function update(string $path, CmsPageDto $dto): void
    {
        $path = $this->normalizePath($path);

        if (!$this->exists($path)) {
            throw new RuntimeException("File not found: {$path}");
        }

        if ($dto->menu !== null) {
            $lang = $this->extractLang($path);

            if ($dto->menu_order === null) {
                $dto->menu_order = $this->orderMenu->resolve(
                    $dto->menu,
                    $lang
                );
            }
        } else {
            $dto->menu_order = null;
        }

        $this->write($path, $dto);
        $this->invalidateIndex();

        $fullPath = $this->loader->getFullPath($path);
        $this->fileBackup($fullPath, true);
    }

    public function delete(string $path): void
    {
        $path = $this->normalizePath($path);

        $full = $this->loader->getFullPath($path);

        if (!is_file($full)) {
            throw new RuntimeException("File not found: {$path}");
        }

        $this->fs->deleteFile($full);
        $this->invalidateIndex();
    }

    public function exists(string $path): bool
    {
        $path = $this->normalizePath($path);

        return is_file($this->loader->getFullPath($path));
    }

    // ===== Private =====

    private function write(string $path, CmsPageDto $dto): void
    {
        $fullPath = $this->loader->getFullPath($path);

        $dir = dirname($fullPath);

        if (!is_dir($dir)) {
            mkdir($dir, 0o775, true);
        }

        $content = $this->buildFrontmatter($dto);

        $this->fs->saveFile($fullPath, $content);
    }

    private function buildFrontmatter(CmsPageDto $dto): string
    {
        return <<<TXT
            ---
            title: {$dto->title}
            description: {$dto->description}
            keywords: {$dto->keywords}
            menu: {$dto->menu}
            menu_order: {$dto->menu_order}
            ---
            {$dto->content}
            TXT;
    }

    private function normalizePath(string $path): string
    {
        $path = trim($path);
        $path = strtolower($path);
        $path = preg_replace(FileLoader::EXT_PATTERN, '', $path);

        return $path;
    }

    private function invalidateIndex(): void
    {
        $file = Paths::joinPaths(Paths::basePath(), CmsIndexBuilder::CACHE_FILE_PATH);

        if (is_file($file) && !unlink($file)) {
            throw new \RuntimeException("Cannot delete cache: " . $file);
        }
    }

    private function extractLang(string $path): ?string
    {
        $parts = explode('/', trim($path, '/'));

        if (count($parts) > 1) {
            return $parts[0];
        }

        return null;
    }

    private function fileBackup(string $fullPath, bool $isUpdate): void
    {
        $contentDir = str_replace('\\', '/', Paths::joinPaths(
            Paths::basePath(),
            CmsIndexBuilder::CONTENT_DIR
        ));

        $fullPath = str_replace('\\', '/', $fullPath);

        $backupDir = Paths::joinPaths(Paths::basePath(), 'storage/backup/cmslite');

        $this->fs->ensureDir($backupDir);

        // BEZPIECZNE wycinanie base path
        if (!str_starts_with($fullPath, $contentDir)) {
            return;
        }

        $relative = ltrim(substr($fullPath, strlen($contentDir)), '/');
        $safeName = str_replace('/', '_', $relative);

        $backupPath = $backupDir . '/' . $safeName . '.bak';

        // CREATE
        if (!$isUpdate) {
            if ($this->fs->isFile($fullPath)) {
                $this->fs->copyFile($fullPath, $backupPath);
            }
            return;
        }

        // UPDATE
        if ($this->fs->isFile($backupPath)) {
            $age = time() - filemtime($backupPath);

            // 7 dni
            if ($age < 7 * 24 * 60 * 60) {
                return;
            }
        }

        if ($this->fs->isFile($fullPath)) {
            if (filesize($fullPath) === 0) {
                return;
            }

            $this->fs->copyFile($fullPath, $backupPath);
        }
    }
}
