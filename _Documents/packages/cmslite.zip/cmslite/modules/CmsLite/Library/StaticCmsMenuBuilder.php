<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 *
 * @INFO
 * Obecnie jest CMS z multi-lang content, ale single-lang routing.
 * Można rozdzielić system o multi-lang routing (SEO future): /pl/about-us, /en/about-us.
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library;

use Dbm\Localization\CurrentLanguage;
use Dbm\Routing\Contracts\UrlGeneratorInterface;

final class StaticCmsMenuBuilder
{
    public function __construct(
        private readonly UrlGeneratorInterface $urlGenerator,
        private readonly CurrentLanguage $currentLanguage
    ) {}

    /**
     * @param array<string, array{
     *   page_key: string,
     *   language: string,
     *   slug: string,
     *   title: string,
     *   description: string,
     *   keywords: string,
     *   menu: ?string,
     *   menu_order: int,
     *   parent: ?string,
     *   path: string
     * }> $index
     *
     * @return array<int, array{
     *   page_key: string,
     *   language: string,
     *   title: string,
     *   url: string,
     *   path: string,
     *   parent: ?string,
     *   order: int,
     *   children: array<int, mixed>,
     *   isActive: bool
     * }>
     */
    public function build(array $index, string $menu, string $current): array
    {
        $items = [];

        $lang = $this->currentLanguage->get();
        $currentLang = $lang ? strtolower($lang) : null;

        foreach ($index as $page) {
            $path = $page['path'];

            if (!$this->matchLang($path, $currentLang)) {
                continue;
            }

            if ($page['menu'] !== $menu) {
                continue;
            }

            $items[$path] = [
                'page_key' => $page['page_key'],
                'language' => $page['language'],
                'title' => $page['title'],
                'url' => $this->buildUrl($path),
                'path' => $path,
                'parent' => $page['parent'],
                'order' => $page['menu_order'],
                'children' => [],
                'isActive' => $this->isActive($path, $current),
            ];
        }

        // --- TREE
        $tree = [];

        foreach ($items as $key => &$item) {
            if ($item['parent']) {
                $parentKey = $this->resolveParentKey($item['parent'], $currentLang);

                if (isset($items[$parentKey])) {
                    $items[$parentKey]['children'][] = &$item;
                    continue;
                }
            }

            $tree[] = &$item;
        }

        unset($item);

        usort($tree, fn($a, $b) => $a['order'] <=> $b['order']);

        return $tree;
    }

    /**
     * @param array<string, array{
     *   page_key: string,
     *   language: string,
     *   slug: string,
     *   title: string,
     *   description: string,
     *   keywords: string,
     *   menu: ?string,
     *   menu_order: int,
     *   parent: ?string,
     *   path: string
     * }> $pages
     *
     * @return array<int, array{
     *   page_key: string,
     *   language: string,
     *   title: string,
     *   url: string,
     *   order: int,
     *   isActive: bool
     * }>
     */
    public function buildFlat(array $pages, string $menuName, string $currentPath): array
    {
        $items = [];

        $lang = $this->currentLanguage->get();
        $currentLang = $lang ? strtolower($lang) : null;

        foreach ($pages as $page) {
            $path = $page['path'];

            if (!$this->matchLang($path, $currentLang)) {
                continue;
            }

            if ($page['menu'] !== $menuName) {
                continue;
            }

            $items[] = [
                'page_key' => $page['page_key'],
                'language' => $page['language'],
                'title' => $page['title'],
                'url' => $this->buildUrl($path),
                'order' => $page['menu_order'],
                'isActive' => $this->isActive($path, $currentPath),
            ];
        }

        usort($items, fn($a, $b) => $a['order'] <=> $b['order']);

        return $items;
    }

    // ===== CORE =====

    private function matchLang(string $path, ?string $lang): bool
    {
        $hasLang = preg_match('#^[a-z]{2}/#', $path);

        // multi lang
        if ($lang !== null) {
            if ($hasLang) {
                return str_starts_with($path, $lang . '/');
            }
            return false;
        }

        // single lang
        return !$hasLang;
    }

    private function resolveParentKey(string $parent, ?string $lang): string
    {
        if ($lang === null) {
            return $parent;
        }

        return str_starts_with($parent, $lang . '/')
            ? $parent
            : $lang . '/' . $parent;
    }

    private function buildUrl(string $path): string
    {
        if (preg_match('#^[a-z]{2}/#', $path)) {
            $path = substr($path, 3);
        }

        return $this->urlGenerator->localizedPath($path);
    }

    private function isActive(string $itemPath, string $currentPath): bool
    {
        $item = $itemPath;

        if (preg_match('#^[a-z]{2}/#', $itemPath)) {
            $item = substr($itemPath, 3);
        }

        $item = trim($item, '/');
        $current = trim($currentPath, '/');

        if ($current === '') {
            return $item === '';
        }

        return $current === $item || str_starts_with($current, $item . '/');
    }
}
