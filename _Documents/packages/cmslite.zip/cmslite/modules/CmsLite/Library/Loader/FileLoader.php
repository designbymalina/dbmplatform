<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 *
 * @INFO Można rozszerzyć o inne formaty:
 * ARRAY_EXTENSIONS = ['txt', 'html', 'md']
 * DEFAULT_EXTENSION = self::ARRAY_EXTENSIONS[0];
 * EXT_PATTERN = '#\.(txt|html|md)$#';
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Loader;

use Dbm\Core\Paths;
use Dbm\Exceptions\NotFoundException;
use Dbm\Infrastructure\Filesystem\Filesystem;
use Dbm\Localization\LanguageHelper;

final class FileLoader
{
    public const EXT_PATTERN = '#\.txt$#';
    public const DEFAULT_EXTENSION = 'txt';

    public function __construct(
        private Filesystem $fs,
        private ?string $basePath = null
    ) {
        $this->basePath = rtrim(
            $basePath ?? Paths::joinPaths(Paths::basePath(), 'data', 'content'),
            '/'
        ) . '/';
    }

    public function load(string $path): string
    {
        $path = strtolower($path);
        $path = preg_replace(self::EXT_PATTERN, '', $path);

        $fullPath = $this->basePath . "{$path}." . self::DEFAULT_EXTENSION;

        $content = $this->fs->readFile($fullPath);

        if ($content !== null) {
            return $content;
        }

        // @TEMPORARY
        $this->temporaryKeyPageBypass($path);

        throw new NotFoundException("CMS page not found: '{$path}'");
    }

    /**
     * @TODO Metoda tymczasowa, wymaga dopracowania getLanguagesData().
     */
    private function temporaryKeyPageBypass(string $path): void
    {
        $default = LanguageHelper::getDefaultLanguage();

        if (preg_match('#^([a-z]{2})/(.+)$#', $path, $match)) {
            $lang = strtolower($match[1]);

            if ($lang === strtolower($default)) {
                $lang = '';
            }

            header('Location: ' . rtrim(getenv('APP_URL'), '/') . '/' . strtolower($lang));
            exit;
        }
    }

    /**
     * Używane w StaticCmsManager
     */
    public function getFullPath(string $path): string
    {
        $path = preg_replace(self::EXT_PATTERN, '', $path);

        return $this->basePath . "{$path}." . self::DEFAULT_EXTENSION;
    }
}
