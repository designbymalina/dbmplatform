<?php

/**
 * Application: DBM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Library\Content;

final class ContentProcessor
{
    public function process(string $content, string|int|null $space = null): string
    {
        $indent = match (true) {
            $space === null || $space === '' => '',
            is_int($space) || ctype_digit((string) $space) => str_repeat('    ', (int) $space),
            default => (string) $space
        };

        return trim(
            str_replace(
                ["\r\n", "\r", "\n", "[URL]"],
                ["\n", "\n", "\n" . $indent, getenv('APP_URL')],
                $content
            )
        ) . "\n";
    }
}
