<?php

declare(strict_types=1);

namespace Mod\CmsLite\Exception;

use Exception;

class UserNotFoundException extends Exception
{
    /**
     * @param string $message
     * @param int $code
     * @param Exception|null $previous
     */
    public function __construct($message = "User does not exist or access denied.", $code = 403, ?Exception $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
