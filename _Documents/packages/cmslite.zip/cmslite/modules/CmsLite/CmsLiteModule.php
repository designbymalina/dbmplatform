<?php

/**
 * Application: DbM Framework + CMS Lite
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite;

use Dbm\Core\DependencyContainer;
use Dbm\Core\Module\PluginModule;
use Dbm\Http\Message\Request;
use Dbm\Infrastructure\Filesystem\Filesystem;
use Dbm\Infrastructure\Sender\MailerInterface;
use Dbm\Localization\Contracts\TranslationInterface;
use Dbm\Localization\LanguageResolver;
use Dbm\Routing\RouteBuilder;
use Dbm\Views\TemplateEngine;
use Mod\CmsLite\Controller\CmsLiteController;
use Mod\CmsLite\Library\Loader\FileLoader;
use Mod\CmsLite\Library\StaticCmsMenuBuilder;
use Mod\CmsLite\Library\StaticCmsReader;
use Mod\CmsLite\Service\CmsLiteService;
use Mod\Shared\Utility\ActivityMonitorUtility;
use Mod\Shared\Utility\NavigationUtility;
use Psr\Log\LoggerInterface;

final class CmsLiteModule extends PluginModule
{
    public function registerRoutes(RouteBuilder $routes): void
    {
        // Overwriting the home page
        $routes->get('/', [CmsLiteController::class, 'index'], 'home');

        // CMS Lite pages (fixed routes)
        $routes->get('/{slug}', [CmsLiteController::class, 'showPage'], 'cmslite_show');

        // CMS Lite pages (parameterized routes)
        $routes->get('/info/{slug}', [CmsLiteController::class, 'showPage'], 'cmslite_info_show')
            ->defaults(['prefix' => 'info']);

        // CMS Lite home page forms
        $routes->post('/ajax-contact', [CmsLiteController::class, 'ajaxContact'], 'cmslite_ajax_contact');
        $routes->post('/ajax-newsletter', [CmsLiteController::class, 'ajaxNewsletter'], 'cmslite_ajax_newsletter');
    }

    public function register(DependencyContainer $container): void
    {
        $container->singleton(
            CmsLiteService::class,
            fn($c) => new CmsLiteService(
                $c->get(StaticCmsReader::class),
                $c->get(ActivityMonitorUtility::class),
                $c->get(TranslationInterface::class),
                $c->get(LoggerInterface::class),
                $c->get(MailerInterface::class)
            )
        );

        $container->singleton(
            FileLoader::class,
            fn($c) => new FileLoader(
                $c->get(Filesystem::class),
            )
        );

        $container->set(NavigationUtility::class, function ($c) {
            return new NavigationUtility(
                $c->get(StaticCmsReader::class),
                $c->get(StaticCmsMenuBuilder::class),
                $c->get(LanguageResolver::class)
            );
        });
    }

    public function boot(): void
    {
        $view = $this->container->get(TemplateEngine::class);

        $view->setGlobal(
            'headerNavigation',
            fn() => $this->container
                ->get(NavigationUtility::class)
                ->getHeader(
                    $this->container->get(Request::class)->getUri()->getPath()
                )
        );

        $view->setGlobal(
            'footerNavigation',
            fn() => $this->container
                ->get(NavigationUtility::class)
                ->getFooter(
                    $this->container->get(Request::class)->getUri()->getPath()
                )
        );
    }
}
