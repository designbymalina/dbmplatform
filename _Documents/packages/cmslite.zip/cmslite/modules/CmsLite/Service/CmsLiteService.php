<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Service;

use Dbm\Infrastructure\Sender\Dto\EmailMessageDto;
use Dbm\Infrastructure\Sender\MailerInterface;
use Dbm\Localization\Contracts\TranslationInterface;
use Mod\CmsLite\Library\StaticCmsReader;
use Mod\CmsLite\Library\Dto\CmsPageDto;
use Mod\Shared\Utility\ActivityMonitorUtility;
use Psr\Log\LoggerInterface;
use Exception;

final class CmsLiteService
{
    public function __construct(
        private readonly StaticCmsReader $cmsReader,
        private readonly ActivityMonitorUtility $activityMonitor,
        private readonly TranslationInterface $translation,
        private readonly LoggerInterface $logger,
        private readonly MailerInterface $mailer,
    ) {}

    /**
     * @return array<string, string>
     */
    public function getMetaIndex(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.index_meta_title'),
            'meta.description' => $this->translation->trans('index.index_meta_description'),
            'meta.keywords' => $this->translation->trans('index.index_meta_keywords'),
        ];
    }

    /**
     * @return array<string, string>
     */
    public function getMetaPage(CmsPageDto $page): array
    {
        return [
            'meta.title' => $page->title,
            'meta.description' => $page->description,
            'meta.keywords' => $page->keywords,
        ];
    }

    public function getPageData(string $path): CmsPageDto
    {
        return $this->cmsReader->get($path);
    }

    public function pagePath(string $slug, ?string $prefix = null): string
    {
        return $this->cmsReader->buildCmsPath($slug, $prefix);
    }

    /**
     * @param array<string> $data
     */
    public function makeContactMessage(array $data): bool
    {
        try {
            if (!$this->sendContactMessage($data)) {
                throw new Exception("Message could not be sent.");
            }

            return true;

        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), [
                'exception' => $exception,
            ]);

            return false;
        }
    }

    public function activityMonitor(string $title, ?int $userId): void
    {
        $user = $userId > 0 ? 'User' : null;
        $this->activityMonitor->logActivity($title, $user);
    }

    // --- helpers ---

    /**
     * @param array<string> $data
     */
    private function sendContactMessage(array $data): bool
    {
        $email = new EmailMessageDto(
            subject: $data['dbm_subject'],
            fromEmail: $data['dbm_email'],
            fromName: $data['dbm_name'],
            body: $data['dbm_message'],
            toEmail: getenv('MAIL_FROM_EMAIL'),
            toName: getenv('MAIL_FROM_NAME'),
        );

        return $this->mailer->send($email);
    }
}
