<?php

/**
 * Application: DbM Framework + CMS
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Controller;

use Dbm\Http\Controller\BaseController;
use Dbm\Http\Message\Response;
use Dbm\Security\CsrfTokenManager;
use Mod\CmsLite\Service\CmsLiteService;
use Mod\CmsLite\Form\CmsLiteContactForm;
use Psr\Http\Message\ResponseInterface;

final class CmsLiteController extends BaseController
{
    public function __construct(
        private readonly CmsLiteService $service,
        private readonly CsrfTokenManager $csrf
    ) {}

    /**
     * Index page
     * @routing GET '/' name: home
     *
     * @return ResponseInterface
     */
    public function index(): ResponseInterface
    {
        $metaData = $this->service->getMetaIndex();
        $this->trackActivity($metaData);

        return $this->render('cmslite/index.phtml', [
            'meta' => $metaData,
        ]);
    }

    /**
     * Show page
     * @routing GET '/show' name: show_index
     *
     * @return ResponseInterface
     */
    public function showPage(string $slug, ?string $prefix = null): ResponseInterface
    {
        $path = $this->service->pagePath($slug, $prefix);
        $page = $this->service->getPageData($path);

        $metaData = $this->service->getMetaPage($page);
        $this->trackActivity($metaData);

        return $this->render('cmslite/show.phtml', [
            'meta' => $metaData,
            'content' => $page->content,
        ]);
    }

    /**
     * Handle contact form submission via AJAX.
     * @routing POST '/ajax-contact' name: cmslite_ajax_contact
     *
     * @return ResponseInterface
     */
    public function ajaxContact(): ResponseInterface
    {
        $bodyParams = (array) $this->request()->getParsedBody();

        if (!$this->csrf->isValid($bodyParams['csrf_token'] ?? '')) {
            return Response::text("Invalid CSRF token.", 403);
        }

        $validator = new CmsLiteContactForm();
        $errors = $validator->validate($bodyParams);

        if (!empty($errors)) {
            return Response::text("Invalid form data.", 422);
        }

        $isSent = $this->service->makeContactMessage($bodyParams);

        return $isSent
            ? Response::text("OK", 200)
            : Response::text("Failed to send message.", 500);
    }

    /**
     * Newsletter form
     * @routing POST '/ajax-newsletter' name: cmslite_ajax_newsletter
     *
     * @return ResponseInterface
     */
    public function ajaxNewsletter(): ResponseInterface
    {
        // @INFO Add newsletter subscription logic here.
        return Response::text("OK", 200);
    }

    // ===== Helpers =====

    /**
     * @param array<string, string> $metaData
     */
    private function trackActivity(array $metaData): void
    {
        $pageTitle = $metaData['meta.title'] ?? 'NoTitle';
        $userId = $this->getUserId();

        $this->service->activityMonitor($pageTitle, $userId);
    }
}
