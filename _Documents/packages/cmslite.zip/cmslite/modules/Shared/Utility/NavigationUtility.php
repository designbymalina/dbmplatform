<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\Shared\Utility;

use Dbm\Core\Paths;
use Mod\CmsLite\Library\StaticCmsMenuBuilder;
use Mod\CmsLite\Library\StaticCmsReader;

final class NavigationUtility
{
    public function __construct(
        private StaticCmsReader $cmsReader,
        private StaticCmsMenuBuilder $cmsMenuBuilder
    ) {}

    // ===== Public API =====

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getHeader(string $currentPath): array
    {
        $currentPath = $this->resolvePath($currentPath);

        return $this->cmsMenuBuilder->build(
            $this->cmsReader->getAllPages(),
            'header',
            $currentPath
        );
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getFooter(string $currentPath): array
    {
        $currentPath = $this->resolvePath($currentPath);

        return $this->cmsMenuBuilder->buildFlat(
            $this->cmsReader->getAllPages(),
            'footer',
            $currentPath
        );
    }

    // ===== Private =====

    private function resolvePath(string $fullPath): string
    {
        $baseFolderName = basename(Paths::basePath());

        $path = parse_url($fullPath, PHP_URL_PATH) ?? '/';

        if (($pos = strpos($path, '/' . $baseFolderName . '/')) !== false) {
            $path = substr($path, $pos + strlen($baseFolderName) + 1);
        }

        return '/' . trim($path, '/');
    }
}
