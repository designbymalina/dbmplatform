<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 *
 * Example usage:
 *
 * ```php
 * use App\Infrastructure\Sender\PHPMailerSender;
 * use Dbm\Infrastructure\Sender\Dto\EmailMessageDto;
 *
 * $email = new EmailMessageDto(
 *     subject: 'Ważna wiadomość',
 *     fromEmail: 'admin@example.com',
 *     fromName: 'Admin',
 *
 *     template: 'template.html', // or body
 *     body: 'raw content',
 *
 *     toEmail: 'user@example.com',
 *     toName: 'User',
 *
 *     // Optional:
 *     params: [
 *         'the_key' => 'The key to your heart.',
 *     ],
 *
 *     recipients: [
 *         ['email' => 'user1@example.com', 'name' => 'User One'],
 *         ['email' => 'user2@example.com', 'name' => 'User Two'],
 *     ],
 *
 *     cc: [
 *         ['email' => 'ccuser@example.com', 'name' => 'CC User'],
 *     ],
 *
 *     bcc: [
 *         ['email' => 'bccuser@example.com', 'name' => 'BCC User'],
 *     ],
 *
 *     attachmentPath: 'filename_1001.zip',
 *     attachmentName: 'FileName.zip',
 *
 *     messageType: 'html', // html | text | null
 * );
 *
 * $mailer->send($email);
 * ```
 */

declare(strict_types=1);

namespace App\Infrastructure\Sender;

use App\Infrastructure\Sender\Enum\RecipientType;
use Dbm\Core\Paths;
use Dbm\Infrastructure\Sender\Dto\EmailMessageDto;
use Dbm\Infrastructure\Sender\MailerInterface;
use Psr\Log\LoggerInterface;
use PHPMailer\PHPMailer\PHPMailer;
use Exception;

final class PHPMailerSender implements MailerInterface
{
    private bool $authentication = true;

    public function __construct(
        private readonly PHPMailer $mailer,
        private readonly LoggerInterface $logger,
    ) {
        $this->mailer->CharSet = 'UTF-8';
    }

    public function send(EmailMessageDto $email): bool
    {
        try {
            // --- CLEAR ---
            $this->mailer->clearAddresses();
            $this->mailer->clearCCs();
            $this->mailer->clearBCCs();
            $this->mailer->clearAttachments();

            // --- SMTP ---
            $this->configureSMTP();

            // --- TEMPLATE / CONTENT ---
            $content = $this->resolveContent($email);

            // --- FROM ---
            $this->mailer->setFrom($email->fromEmail, $email->fromName);

            // --- RECIPIENTS ---
            $this->applyRecipients($email);

            // --- SUBJECT ---
            $this->mailer->Subject = $email->subject;

            // --- BODY FORMAT ---
            $this->setMessageFormat($content, $email->messageType);

            // --- ATTACHMENT ---
            $this->addAttachment($email);

            return $this->mailer->send();

        } catch (Exception $e) {
            $this->logger->error('Mail send failed', [
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    private function resolveContent(EmailMessageDto $email): string
    {
        if ($email->template) {
            $path = Paths::joinPaths(
                Paths::basePath(),
                'data',
                'mailer',
                $email->template
            );

            $content = file_exists($path)
                ? file_get_contents($path)
                : ($email->body ?? '');
        } else {
            $content = $email->body ?? '';
        }

        $params = $this->buildTemplateContext($email);

        return $this->replaceContent($content, $params);
    }

    private function applyRecipients(EmailMessageDto $email): void
    {
        if (!empty($email->recipients)) {
            $this->addRecipients($email->recipients, RecipientType::To);
            $this->addRecipients($email->cc, RecipientType::Cc);
            $this->addRecipients($email->bcc, RecipientType::Bcc);
            return;
        }

        if ($email->toEmail) {
            $this->mailer->addAddress($email->toEmail, $email->toName);
            return;
        }

        throw new Exception("No message recipients were specified.");
    }

    private function addAttachment(EmailMessageDto $email): void
    {
        if (!$email->attachmentPath || !$email->attachmentName) {
            return;
        }

        $path = Paths::joinPaths(
            Paths::basePath(),
            'data',
            'attachment',
            $email->attachmentPath
        );

        if (!is_file($path)) {
            throw new Exception("Attachment not found: {$path}");
        }

        $this->mailer->addAttachment($path, $email->attachmentName);
    }

    private function setMessageFormat(string $content, ?string $type): void
    {
        if ($type === 'html') {
            $this->mailer->isHTML(true);
            $this->mailer->Body = $content;
        } elseif ($type === 'text') {
            $this->mailer->isHTML(false);
            $this->mailer->Body = strip_tags($content);
        } else {
            $this->mailer->MsgHTML($content);
        }
    }

    /**
     * @param array<int, mixed> $recipients
     */
    private function addRecipients(array $recipients, RecipientType $type): void
    {
        foreach ($recipients as $r) {
            $email = $r['email'] ?? null;
            $name = $r['name'] ?? '';

            if (!$email) {
                continue;
            }

            match ($type) {
                RecipientType::To => $this->mailer->addAddress($email, $name),
                RecipientType::Cc => $this->mailer->addCC($email, $name),
                RecipientType::Bcc => $this->mailer->addBCC($email, $name)
            };
        }
    }

    /**
     * @param array<string, string> $params
     */
    private function replaceContent(string $content, array $params): string
    {
        $placeholders = array_map(
            fn($key) => '{' . $key . '}',
            array_keys($params)
        );

        return str_replace($placeholders, $params, $content);
    }

    /**
     * @return array<string, string>
     */
    private function buildTemplateContext(EmailMessageDto $email): array
    {
        return array_merge($email->params, [
            'subject' => $email->subject,
            'from_name' => $email->fromName,
            'from_email' => $email->fromEmail,
            'to_name' => $email->toName,
            'to_email' => $email->toEmail,
            'attachment_path' => $email->attachmentPath ?? '',
            'attachment_name' => $email->attachmentName ?? '',
        ]);
    }

    private function configureSMTP(): void
    {
        if (!filter_var(getenv('MAIL_SMTP'), FILTER_VALIDATE_BOOLEAN)) {
            return;
        }

        $this->mailer->isSMTP();
        $this->mailer->SMTPAuth = $this->authentication;

        $this->mailer->Host = getenv('MAIL_HOST');
        $this->mailer->Port = getenv('MAIL_PORT') ?: 1025;

        if ($secure = getenv('MAIL_SECURE')) {
            $this->mailer->SMTPSecure = $secure;
        }

        if ($this->authentication) {
            $this->mailer->Username = getenv('MAIL_USERNAME');
            $this->mailer->Password = getenv('MAIL_PASSWORD');
        }
    }
}
