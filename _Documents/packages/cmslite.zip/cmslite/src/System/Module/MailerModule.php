<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\System\Module;

use App\Infrastructure\Sender\PHPMailerSender;
use App\System\Contracts\SystemModuleInterface;
use Dbm\Core\DependencyContainer;
use Dbm\Infrastructure\Sender\MailerInterface;
use PHPMailer\PHPMailer\PHPMailer;
use Psr\Log\LoggerInterface;

final class MailerModule implements SystemModuleInterface
{
    public function register(DependencyContainer $container): void
    {
        $container->singleton(PHPMailer::class, fn() => new PHPMailer(true));

        $container->singleton(
            MailerInterface::class,
            fn($c) => new PHPMailerSender(
                $c->get(PHPMailer::class),
                $c->get(LoggerInterface::class)
            )
        );
    }

    public static function canRegister(): bool
    {
        return getenv('MAIL_FROM_EMAIL') !== false;
    }
}
